package com.yourpackagename.yourwebproject.webapp.dispatcher;

import com.yourpackagename.framework.dispatcher.BaseDispatcherServlet;

/**
 * Dispatcher servlet for YourWebProject Webapp
 *
 * @author: Y Kamesh Rao
 * @created: 3/24/12 5:53 PM
 * @company: &copy; 2012, Kaleidosoft Labs
 */
public class YourWebProjectWebAppDispatcherServlet extends BaseDispatcherServlet {
}
