package com.yourpackagename.yourwebproject.api.dispatcher;

import com.yourpackagename.framework.dispatcher.BaseDispatcherServlet;

/**
 * Dispatcher servlet for Your Web Project API
 *
 * @author: Y Kamesh Rao
 * @created: 3/24/12 5:51 PM
 * @company: &copy; 2012, Kaleidosoft Labs
 */
public class YourWebProjectApiDispatcherServlet extends BaseDispatcherServlet {
}
