package com.yourpackagename.framework.common;

/**
 * Framework level constants
 *
 * @author: Y Kamesh Rao
 * @created: 3/17/12 9:50 PM
 * @company: &copy; 2012, Kaleidosoft Labs
 */
public class Const {
    public static final String responseKey = "response";
}
