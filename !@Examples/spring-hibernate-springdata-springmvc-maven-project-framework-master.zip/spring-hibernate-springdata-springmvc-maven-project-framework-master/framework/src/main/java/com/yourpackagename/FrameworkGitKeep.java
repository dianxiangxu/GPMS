package com.yourpackagename;

/**
 * Dummy class to help you refactor the package names.
 *
 * @author: Y Kamesh Rao
 * @created: 7/7/12 2:46 PM
 * @company: &copy; 2012, Kaleidosoft Labs
 */
public class FrameworkGitKeep {
}
