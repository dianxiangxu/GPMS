package com.yourpackagename.framework.common;

/**
 * @author: Y Kamesh Rao
 * @created: 5/1/12 2:08 PM
 * @company: &copy; 2012, Kaleidosoft Labs
 */
public class Key {
    public static final String meta = "meta";
    public static final String result = "result";
    public static final String response = "response";
    public static final String id = "id";
}
