A Morphia demo. Morphia is a type-safe library for mapping Java objects to/from MongoDB. See http://code.google.com/p/morphia/ for Morphia documentation.



