+++
date = "2015-03-17T15:36:56Z"
title = "Morphia"
type = "index"
+++

## Morphia Documentation

Welcome to the Morphia documentation hub.

Morphia is built upon the 
[`MongoDB Java Driver`](https://github.com/mongodb/mongo-java-driver/). 
For reference documentation please see the driver documentation.


### Getting Started

The [Getting Started]({{< relref "getting-started/index.md" >}}) guide contains installation instructions
and a simple tutorial to get up and running quickly.