package org.mongodb.morphia.logging;

/**
 * @deprecated Use LoggerFactory directly
 */
@Deprecated
public interface LogrFactory extends LoggerFactory {
}
