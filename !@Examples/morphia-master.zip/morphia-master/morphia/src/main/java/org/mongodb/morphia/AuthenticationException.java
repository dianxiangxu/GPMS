package org.mongodb.morphia;


public class AuthenticationException extends RuntimeException {

  public AuthenticationException(final String msg) {
    super(msg);
  }
}
