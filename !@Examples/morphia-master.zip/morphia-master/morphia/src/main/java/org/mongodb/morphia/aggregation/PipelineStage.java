package org.mongodb.morphia.aggregation;

public class PipelineStage {
    private final String name;

    public PipelineStage(final String name) {
        this.name = name;
    }
}
