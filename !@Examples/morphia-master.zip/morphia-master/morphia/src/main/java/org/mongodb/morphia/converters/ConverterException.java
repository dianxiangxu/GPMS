package org.mongodb.morphia.converters;


public class ConverterException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public ConverterException(final String msg) {
    super(msg);
  }
}
