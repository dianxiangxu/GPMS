

There is a short instruction how to set up ssl functionality.

1. Generate keystore file as follow:

-----------------------------------------------------------------
C:\Program Files\Java\jdk1.6.0_26\bin>keytool -keystore keystore -alias file_uploader -genkey -keyalg RSA
Enter keystore password:
Re-enter new password:
What is your first and last name?
  [Unknown]:  localhost
What is the name of your organizational unit?
  [Unknown]:
What is the name of your organization?
  [Unknown]:
What is the name of your City or Locality?
  [Unknown]:
What is the name of your State or Province?
  [Unknown]:
What is the two-letter country code for this unit?
  [Unknown]:
Is CN=localhost, OU=Unknown, O=Unknown, L=Unknown, ST=Unknown, C=Unknown correct?
  [no]:  yes

Enter key password for <file_uploader>
        (RETURN if same as keystore password):
Re-enter new password:

-----------------------------------------------------------------

As you can see I typed Last Name and First Name = localhost. You should change the value to your server host name

2. Put keystore file into /conf directory

3. In the conf.properties set use.ssl=true

4. In the ssl.properties set up passwords and ssl port. Use org.mortbay.jetty.security.Password to obfuscate the passwords.

Done! 