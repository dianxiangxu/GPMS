
package com.jverstry.Item;

public class MilliTimeItem {
	
	private long milliTime = 0;
	
	public MilliTimeItem() { }
	
	public MilliTimeItem(long init) {
		this.milliTime = init;
	}

	public long getMilliTime() {
		return milliTime;
	}

	public void setMilliTime(long milliTime) {
		this.milliTime = milliTime;
	}
	
}
