
package com.jverstry.IoCContainer;

public interface MyService {
	
	public long getData();
	
}
