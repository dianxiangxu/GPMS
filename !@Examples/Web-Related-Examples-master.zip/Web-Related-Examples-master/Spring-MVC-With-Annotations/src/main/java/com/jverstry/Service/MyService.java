
package com.jverstry.Service;

import org.springframework.stereotype.Service;

@Service
public interface MyService {
	
	long getCurrentTimeInMilliseconds();
	
}
