
package com.jverstry.Service;

import com.jverstry.Item.MilliTimeItem;

public interface MyService {
	
	MilliTimeItem createAndRetrieve();
	
}
