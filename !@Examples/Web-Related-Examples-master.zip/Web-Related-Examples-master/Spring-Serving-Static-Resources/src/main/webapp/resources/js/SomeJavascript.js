
$(document).ready(function() {
	alert("JS loaded successfully!");
});