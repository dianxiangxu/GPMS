
package com.jverstry.Service;

public interface MyService {
	
	long getCurrentTimeInMilliseconds();
	
}
