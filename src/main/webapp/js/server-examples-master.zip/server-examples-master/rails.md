Please have a look at [this wiki page](https://github.com/Widen/fine-uploader-server/wiki/Rails---CarrierWave) if you are using Rails
