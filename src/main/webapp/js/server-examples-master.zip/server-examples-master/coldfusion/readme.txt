Coldfusion example by Patrick Hedgepath - Pegasus Web Productions LLC - www.pegweb.com

Code has been tested with version 2.0 of Valum's AJAX file uploader on Cold Fusion Enterprise 9.x server
If you have any improvements to this code please feel free to email them to me webmaster@pegweb.com

Questions, problems, comments? Go to the forums and post https://github.com/Widen/fine-uploader
