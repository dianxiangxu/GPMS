﻿

var Brand = {


       "Top Brands": "Top Brands",
    "Popular Brands": "Popular Brands",

    "loading....": "loading....",
    "View as:": "View as:",
    "Sort by:": "Sort by:",

    'Delete Confirmation': 'Delete Confirmation',
    'Are you sure you want to delete this brand?': 'Are you sure you want to delete this brand?',
    'Successful Message': 'Successful Message',
    'Error Message': 'Error Message',
    'Failed to delete brand': 'Failed to delete brand',
    'Editing Brand: ': 'Editing Brand: ',
    'Information Message': 'Information Message',
    'error': 'error',
    'Brand has been deleted successfully.': 'Brand has been deleted successfully.',
    'Brand DeActivated successfully': 'Brand DeActivated successfully',
    'Brand Activated successfully': 'Brand Activated successfully',
    'Brand Updated successfully': 'Brand Updated successfully',
    'Brand Inserted successfully': 'Brand Inserted successfully',
    'Alert Message': 'Alert Message',
    'Not a valid image!': 'Not a valid image!',
    'Can not upload the image!': 'Can not upload the image!',
    'Information Alert': 'Information Alert',
    'None of the brand are selected': 'None of the brand are selected',
    'Do you want to delete?': 'Do you want to delete?',
    'Choose Image!': 'Choose Image!',
    'Brand Exists': 'Brand Exists',
    'Please choose another brand name': 'Please choose another brand name',
    'Please enter brand name!': 'Please enter brand name!',
    'The store has no brand!': 'The store has no brand!',
    "Featured Brands": "Featured Brands",
    "The store has no featured brand!": "The store has no featured brand!",
    "Please enter valid date!": "Please enter valid date!",



   
    "Sorry, Failed to load brand items results!": "Sorry, Failed to load brand items results!",

       'Brands': 'Brands',
    'A-D': 'A-D',
    'E-L': 'E-L',
    'M-P': 'M-P',
    'Q-Z': 'Q-Z',
    "View All Brands": "View All Brands",
    "All Brands":"All Brands",
    "BrandID": "BrandID",
    "Brand Name": "Brand Name",
    "Brand Description": "Brand Description",
    "Brand Image": "Brand Image",
    "Slider View": "Slider View",
    "Featured":"Featured",
       "Featured From": "Featured From",
    "Featured To": "Featured To",
    "Active": "Active",
    "Actions": "Actions",
    "Edit": "Edit",
    "Delete": "Delete",
    "Activate": "Activate",
    "Deactivate": "Deactivate",
    "No Records Found!": "No Records Found!",
      "Show All":"Show All",
    "Add New Brand":"Add New Brand",
    "Delete All Selected":"Delete All Selected",
    "Brand Name:":"Brand Name:",
    "Search":"Search",
    "Save":"Save",
    "Cancel": "Cancel",
    "Select Langauge:": "Select Langauge:"
   

};