﻿var gpmsProposalsManagement = {
	"Is Deleted?" : "Is Deleted?",
	"Added On" : "Added On",
	"Last Updated" : "Last Updated",
	"Actions" : "Actions",
	"Edit" : "Edit",
	"Activate" : "Activate",
	"Deactivate" : "Deactivate"
};
