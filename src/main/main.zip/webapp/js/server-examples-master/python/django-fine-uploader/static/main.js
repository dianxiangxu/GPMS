$(document).ready(function() {

    /** instantiate Fine Uploader here */

});
